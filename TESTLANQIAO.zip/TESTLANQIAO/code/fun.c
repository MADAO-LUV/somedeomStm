#include "headfile.h"
uint8_t keystate;
uint8_t key_last_state;

void LED_ON(uint8_t led,uint8_t mode)
{
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
	if(mode)
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8<<(led-1),GPIO_PIN_RESET);
	else
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8<<(led-1),GPIO_PIN_SET);

}



void Key_Scan()
{
	keystate = HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0);
	if(keystate == 0 && key_last_state == 1)
	{
		LED_ON(1,1);
	}
	key_last_state = keystate;

}