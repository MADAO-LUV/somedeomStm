#ifndef _fun_h
#define _fun_h
#include "headfile.h"

void LED_ON(uint8_t led,uint8_t mode);
void Key_Scan();
#endif